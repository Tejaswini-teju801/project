package com.demo;

public class Employee {
	
	String empname;

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}
	 public void printName()
	 {
		 System.out.println("hello employee!!!"+empname);
	 }

}
