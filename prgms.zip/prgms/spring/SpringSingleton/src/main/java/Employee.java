
public class Employee {
static int count;
Employee()
{
	count++;
}
public int getData() {
	return count;
}

}
