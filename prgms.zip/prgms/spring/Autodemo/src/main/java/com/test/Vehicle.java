package com.test;

public interface Vehicle {
void move();
}
