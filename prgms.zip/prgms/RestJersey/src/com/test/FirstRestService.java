package com.test;

	import javax.ws.rs.GET;
	import javax.ws.rs.Path;
	import javax.ws.rs.Produces;
	import javax.ws.rs.core.Response;
	 
	@Path("/employee")

		public class FirstRestService 
		{
	 
	  @GET
	  @Path("/intemployee")
	  @Produces("text/html")
	  
	  public Response getInternEmployeeDet()
	  {
	 
	           String output = "<font color=blue>Message from Internal Employee Details ";
	           //return Response.status(404).entity(output).build();
	           
	          return Response.status(200).encoding(output).build();
	  }
	 
	  
	  
	  
	  
	  
	  
	  
	  
	  /*@GET
	  @Path("/extemployee")
	  @Produces("text/html")
	  public Response getExtEmployeeDet() {
	 
	            String output = "Message from external employee";
	            return Response.status(200).entity(output).build();
	  }
*/
	  }