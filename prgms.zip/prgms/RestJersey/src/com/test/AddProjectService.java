package com.test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;


 
@Path("/addemployee")
public class AddProjectService {
	 
   @POST
       @Produces("application/json")
    public Employee AddEmployeeDetails(
                    @FormParam("ename") String empname,@FormParam("eid") int empid,@FormParam("elocation") String location)
                {
    	Employee ad=new Employee();
    	ad.setEid(empid);
    	ad.setLocation(location);
    	ad.setName(empname);
    	
	/*String		 output = "Added Employee Succesfully:<u>"+ad+"</u></font>";
       return Response.status(200).entity(output).build();
 */
 return ad;
 
                }



}
