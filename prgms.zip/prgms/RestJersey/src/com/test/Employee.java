package com.test;
public class Employee {
int eid;
String name;
String location;
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
@Override
public String toString() {
	return "Employee [eid=" + eid + ", name=" + name + ", location=" + location + "]";
}

}
