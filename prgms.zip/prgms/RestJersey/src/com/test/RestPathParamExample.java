package com.test;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

@Path("/empdata")
public class RestPathParamExample {

	@Path("/{eid}/{ename}")
	@POST
	public Response addData(@PathParam ("eid") int eid,@PathParam("ename") String ename) {
        
        String output = "Employee id - "+eid+",name - "+ename+"";
        return Response.status(200).entity(output).build();
 
	}
		

	//http://localhost:8989/RestJersey/rest/empdata/101/teju
	
	
}
