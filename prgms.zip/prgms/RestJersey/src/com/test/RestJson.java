package com.test;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/emp")
public class RestJson {
	
@Path("/{empno}")	
@GET
@Produces(MediaType.APPLICATION_JSON)
public Employee addData(@PathParam ("empno") int eid) {
    
    Employee emp=new Employee();
    emp.setEid(eid);
    emp.setName("tejaswini");
    emp.setLocation("Hyderabad");
	return emp;

}
}//http://localhost:8989/RestJersey/rest/emp/101