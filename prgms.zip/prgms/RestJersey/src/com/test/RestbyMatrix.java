package com.test;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
 
@Path("/employeedatam")
	public class RestbyMatrix {

    @GET
    @Produces("text/html")
    public Response getValue(
                    @MatrixParam("enameKey") String ename,
                    @MatrixParam("locationKey") String location) {
        
        String output = "Employee name - "+ename+",Location - "+location+"";
        return Response.status(200).entity(output).build();
 
    }
}


//http://localhost:8065/AllServices/rest/employeedatam;enameKey=abc;locationKey=India


