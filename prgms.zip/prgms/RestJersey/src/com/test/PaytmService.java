package com.test;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;



@Path("/paytm")
public class PaytmService 
{

	@GET
	@Path("/listall") // creating endpoint
	  @Produces("text/html")
	public String getListofPaytmServices()
	{		
		return "Banking,Shopping,busbooking";
	}

	@GET
	@Path("/booking")
	  @Produces("text/html")
	public String BusTicketBooking()
	{		
		return "Select the bus for Booking";
	}

	

}