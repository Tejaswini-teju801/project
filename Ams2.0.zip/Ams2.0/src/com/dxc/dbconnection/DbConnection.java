package com.dxc.dbconnection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class DbConnection {


static public Session connect()
{
	Session ses=null;
	try
	{
		SessionFactory sfg= new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();

	 ses=sfg.openSession();
	       
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	return ses;
		
}
}
