package com.dxc.ams2.service;

import java.util.List;

import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Appointment;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.Customer;
import com.dxc.ams2.entity.Login;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.Policy;
import com.dxc.ams2.entity.ZonalManager;

public interface ServiceLayer {
	
	
	//SERVICES FOR ALL( *for Customer only viewPolicy()*)
	public String login(Login login);
	public List<Manager> viewManager();
	public List<Agent> viewAgent();
	public List<Policy> viewPolicy();
	
	
	
	//ZONAL MANAGER TASKS
	
	public List<ZonalManager> viewzonal();
	public boolean addManager(Manager mngr);
	
	public boolean addBranch(Branch br);
	
	public boolean replaceManager(String id,String brno);
	
	
	
	//MANAGER SPECIFIC TASKS
	public boolean addAgent(Agent ag);
	public List<Agent> viewPerformance();
	public boolean setTarget(String agno, String date);

	
	//AGENT SPECIFIC TASKS
	public List<Customer> viewCustomer(String id);
	public boolean addCustomer(Customer cust);
	public boolean makeAppointment(Appointment appt);
	public List<Appointment> viewAppointment();
	public boolean deleteAppt(String id);
	
	//CUSTOMER SPECIFIC TASKS
	public boolean changePwd(String id,String pwd);
	public List<Customer> viewCust(String id);
	

}
