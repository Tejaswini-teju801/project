package com.dxc.ams2.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.ams2.dao.ImplClass;
import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Appointment;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.Customer;
import com.dxc.ams2.entity.Login;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.Policy;
import com.dxc.ams2.entity.ZonalManager;
@Service
public class ServiceImpl implements ServiceLayer{
ImplClass imp=new ImplClass();
	@Override
	public String login(Login login) {
		// TODO Auto-generated method stub
	return imp.loginz(login);
	}

	@Override
	public List<ZonalManager> viewzonal() {
		// TODO Auto-generated method stub
		
	
		return  imp.viewzonal();
	}

	@Override
	public boolean addManager(Manager mngr) {
		// TODO Auto-generated method stub
		 return imp.addManager(mngr);
	}

	@Override
	public List<Manager> viewManager() {
		// TODO Auto-generated method stub
		return imp.viewManager();
	}
	@Override
	public boolean addBranch(Branch br) {
		// TODO Auto-generated method stub
		
			return imp.addBranch(br);
	}

	@Override
	public List<Agent> viewAgent() {
		// TODO Auto-generated method stub
		
		return imp.viewAgent();
	}

	@Override
	public List<Policy> viewPolicy() {
		// TODO Auto-generated method stub
		 
		return imp.viewPolicy();
	}

	@Override
	public boolean replaceManager(String id, String brno) {
		// TODO Auto-generated method stub
	
			return imp.replaceManager(id, brno);
	}
	
	
//manager tasks
	
	
	@Override
	public boolean addAgent(Agent ag) {
		// TODO Auto-generated method stub
		
			return imp.addAgent(ag);
	}

	@Override
	public List<Agent> viewPerformance() {
		// TODO Auto-generated method stub
		return imp.viewPerformance();
	}

	@Override
	public boolean setTarget(String agno, String date) {
		// TODO Auto-generated method stub
		return imp.setTarget(agno, date);
	}
	
	
//agent specific
	@Override
	public List<Customer> viewCustomer(String id) {
		// TODO Auto-generated method stub

		return imp.viewCustomer(id);
	}

	@Override
	public boolean addCustomer(Customer cust) {
		// TODO Auto-generated method stub
		
			return imp.addCustomer(cust);
	}

	@Override
	public boolean makeAppointment(Appointment appt) {
		// TODO Auto-generated method stub
		return imp.makeAppointment(appt);
	}

	@Override
	public List<Appointment> viewAppointment() {
		// TODO Auto-generated method stub
		return imp.viewAppointment();
	}

	@Override
	public boolean deleteAppt(String id) {
		// TODO Auto-generated method stub
		return imp.deleteAppt(id);
	}
	
	
	
//customer specific
	@Override
	public boolean changePwd(String id, String pwd) {
		// TODO Auto-generated method stub
		
			  return imp.changePwd(id, pwd);
	}

	@Override
	public List<Customer> viewCust(String id) {
		// TODO Auto-generated method stub
		
		return imp.viewCust(id);

}
}