package com.dxc.ams2.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.ams2.dao.AgentService;
import com.dxc.ams2.dao.CustomerService;
import com.dxc.ams2.dao.ImplClass;
import com.dxc.ams2.dao.ManagerService;
import com.dxc.ams2.dao.ZonalService;
import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Appointment;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.Customer;
import com.dxc.ams2.entity.Login;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.Policy;
import com.dxc.ams2.entity.ZonalManager;
import com.dxc.ams2.service.ServiceImpl;

@Controller
public class AmsController {

	ServiceImpl i=new ServiceImpl();
//view list of Zonalmanager
	@RequestMapping(value = "/zonalmanagerlist")
	public ModelAndView getZonalManagerList() {

		List<ZonalManager> l = i.viewzonal();

		return new ModelAndView("display", "zm", l);
	}
	

	
//view list of managers
	@RequestMapping(value = "/viewmanager")
	public ModelAndView getManagerList() {

		List<Manager> l = i.viewManager();

		return new ModelAndView("displaym", "m", l);
	}
	
	
	
//view list of agents	
	@RequestMapping(value = "/agentlist")
	public ModelAndView getAgentList() {

		List<Agent> l = i.viewAgent();

		return new ModelAndView("displaya", "agent", l);
	}

	
//view policy details
	@RequestMapping(value = "/viewpolicy")
	public ModelAndView getPolicyDetails() {

		List<Policy> l = i.viewPolicy();

		return new ModelAndView("displaypol", "policy", l);
	}

	
	/*
	 * @RequestMapping(value="/addmanagers",method=RequestMethod.POST) public
	 * ModelAndView getData(@RequestParam("id") String
	 * id,@RequestParam("fname")String fname,
	 * 
	 * @RequestParam("lname") String lname,@RequestParam("lnname") String lnname,
	 * 
	 * @RequestParam("pwd") String pwd,
	 * 
	 * @RequestParam("email") String email,@RequestParam("address") String address,
	 * 
	 * @RequestParam("phno") String phno,@RequestParam("brno") String brno) {
	 * 
	 * 
	 * 
	 * Manager m=new Manager(id,fname,lname,lnname,pwd,email,address,phno,brno);
	 * zs.addManager(m);
	 * 
	 * return new ModelAndView("success","details",fname); }
	 */
	

// add managers using modelattribute	
	  @RequestMapping(value="/addmanagers",method=RequestMethod.POST) 
	  public ModelAndView createManager(@ModelAttribute Manager manager) {
	  
	 if( i.addManager(manager)) 
	  return new ModelAndView("success","details",manager.getFirstname());
	  
	  else 
		  return new ModelAndView("failure","details",manager.getFirstname());
	  	  
	  }
	  
	  
	  
	  
//add new branch 
	  
	  @RequestMapping(value = "/addbranches", method = RequestMethod.POST)
		public ModelAndView createBranch(@ModelAttribute Branch branch) {
			if(i.addBranch(branch))
			    return new ModelAndView("successbr", "details", branch.getBrno());
			else
				return new ModelAndView("failure","detail", branch.getBrno());
		}  
	  
	  
		/*
		 * @RequestMapping(value = "/addbranches", method = RequestMethod.POST) public
		 * ModelAndView createBranch(@RequestParam("brno") String
		 * brno, @RequestParam("brname") String brname,
		 * 
		 * @RequestParam("braddr") String braddr, @RequestParam("zmno") String zmno) {
		 * 
		 * Branch b = new Branch(brno, brname, braddr, zmno); zs.addBranch(b);
		 * 
		 * return new ModelAndView("successbr", "details", brno); }
		 */
	  
	  
//replace manager
	@RequestMapping(value = "/replacemanager", method = RequestMethod.POST)
	public ModelAndView replaceManagers(@RequestParam("id") String id, @RequestParam("brno") String brno) {
		if(i.replaceManager(id, brno)) {
			
		return new ModelAndView("successrep", "details", brno);

	}
		else return new ModelAndView("failure", "detail", brno);
			
	}


	/*
	 * @RequestMapping(value = "/addagents", method = RequestMethod.POST) public
	 * ModelAndView createAgent(@RequestParam("id") String
	 * id, @RequestParam("fname") String fname,
	 * 
	 * @RequestParam("lname") String lname, @RequestParam("lnname") String
	 * lnname, @RequestParam("pwd") String pwd,
	 * 
	 * @RequestParam("email") String email, @RequestParam("address") String address,
	 * 
	 * @RequestParam("phno") String phno, @RequestParam("brno") String
	 * brno, @RequestParam("policy") String policy,
	 * 
	 * @RequestParam("target") int target, @RequestParam("psold") int
	 * psold, @RequestParam("tdate") String tdate,
	 * 
	 * @RequestParam("edate") String edate) {
	 * 
	 * Agent a = new Agent(id, fname, lname, lnname, pwd, brno, policy, address,
	 * phno, email, target, psold, tdate, edate); ms.addAgent(a);
	 * 
	 * return new ModelAndView("successag", "details", fname); }
	 */
	@RequestMapping(value = "/addagents", method = RequestMethod.POST)
	public ModelAndView createAgent(@ModelAttribute Agent agent) {

		if(i.addAgent(agent))
		      return new ModelAndView("successag", "details", agent.getFirstname());
		else
			 return new ModelAndView("failure", "details", agent.getFirstname());
			
	}
	
	
//view agents performance	
	@RequestMapping(value = "/agentperf")
	public ModelAndView getAgentPerformance() {

		List<Agent> l = i.viewPerformance();
		return new ModelAndView("displayaperf", "ag", l);
	}
	
	
//set target for agents
	@RequestMapping(value = "/settargetdate", method = RequestMethod.POST)
	public ModelAndView setTargets(@RequestParam("id") String id, @RequestParam("date") String date) {
		if(i.setTarget(id, date))
		    return new ModelAndView("successtarget", "details", id);
		else
			return new ModelAndView("failure", "details", id);

	}
	
	



	
//make appointment	
	/*
	 * @RequestMapping(value = "/makeappt", method = RequestMethod.POST) public
	 * ModelAndView createAppointment(@RequestParam("id") String
	 * id, @RequestParam("date") String date,
	 * 
	 * @RequestParam("time") String time, @RequestParam("agno") String
	 * agno, @RequestParam("cstno") String cstno,
	 * 
	 * @RequestParam("cstname") String cstname) {
	 * 
	 * Appointment appt = new Appointment(id, date, time, agno, cstno, cstname);
	 * as.makeAppointment(appt);
	 * 
	 * return new ModelAndView("successag", "details", id); }
	 */
	
	@RequestMapping(value = "/makeappt", method = RequestMethod.POST)
	public ModelAndView createAppointment(@ModelAttribute Appointment appt) {

		
		if(i.makeAppointment(appt))
		    return new ModelAndView("successc", "details", appt.getApptno());
		else
			return new ModelAndView("failure", "details", appt.getApptno());
	}

	
//view appointments	
	@RequestMapping(value = "/viewappointment")
	public ModelAndView getAppointmentList() {

		List<Appointment> l = i.viewAppointment();

		return new ModelAndView("displayappt", "at", l);
	}

	
//delete appointments
	@RequestMapping(value = "/delappt")
	public ModelAndView getDatadelappt(@RequestParam("id") String id) {

		if(i.deleteAppt(id))
		    return new ModelAndView("successdel", "details", id);
		else
			return new ModelAndView("failure", "details", id);
	}

	
// add customer
	/*
	 * @RequestMapping(value = "/addcustomer", method = RequestMethod.POST) public
	 * ModelAndView createCustomer(@RequestParam("id") String
	 * id, @RequestParam("fname") String fname,
	 * 
	 * @RequestParam("lname") String lname, @RequestParam("lnname") String lnname,
	 * 
	 * @RequestParam("email") String email, @RequestParam("pwd") String pwd,
	 * 
	 * @RequestParam("address") String address, @RequestParam("phno") String phno,
	 * 
	 * @RequestParam("agno") String agno) {
	 * 
	 * Customer c = new Customer(id, fname, lname, lnname, pwd, email, address,
	 * phno, agno); if(as.addCustomer(c)) return new ModelAndView("successc",
	 * "details", fname); else return new ModelAndView("failure", "details", fname);
	 * 
	 * }
	 */

	@RequestMapping(value = "/addcustomer", method = RequestMethod.POST)
	public ModelAndView createCustomer(@ModelAttribute Customer customer) {

		if(i.addCustomer(customer))
			return new ModelAndView("successc", "details", customer.getCstfirstname());
		else
			return new ModelAndView("failure", "details", customer.getCstfirstname());
			
	}

	
	
	
	
	
	
//view all customers list
	@RequestMapping(value = "/viewcustomer")
	public ModelAndView getCustomerList(@RequestParam("id") String id) {

		List<Customer> l = i.viewCustomer(id);

		return new ModelAndView("displayc", "cust", l);
	}

	
	
	
	
//specific to one customer
	@RequestMapping(value = "/viewdetails")
	public ModelAndView getCustomerdetails(@RequestParam("id") String id) {

		List<Customer> l = i.viewCust(id);

		return new ModelAndView("displayc", "cust", l);
	}

	
//change password by customer
	@RequestMapping(value = "/change")
	public ModelAndView changePaasword(@RequestParam("id") String id, @RequestParam("pwd") String pwd) {

		if(i.changePwd(id, pwd))
		  return new ModelAndView("displaychange", "details", pwd);
		else 
			return new ModelAndView("failure", "details", id);
	}

	
//login for all
	@RequestMapping(value = "/login")
	public ModelAndView loginToSystem(@ModelAttribute Login login) {

		String r = i.login(login);
		
		if (r.equalsIgnoreCase("zonalmanager"))
			return new ModelAndView("Zonal", "details", login.getLoginname());
		else if (r.equalsIgnoreCase("manager"))
			return new ModelAndView("managertask", "details", login.getLoginname());
		else if (r.equalsIgnoreCase("agent"))
			return new ModelAndView("agenttask", "details", login.getLoginname());
		else if (r.equalsIgnoreCase("customer"))
			return new ModelAndView("customer", "details", login.getLoginname());

		return new ModelAndView("failure", "details", login.getLoginname());
	}
}
