package com.dxc.ams2.dao;

import java.util.List;

import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.Policy;
import com.dxc.ams2.entity.ZonalManager;

public interface ManagerService {

	//public boolean login(String user,String pwd);

	public boolean addAgent(Agent ag);
	public List<Manager> viewManager();
	public List<Agent> viewAgent();
	public List<Policy> viewPolicy();
	public List<Agent> viewPerformance();
	public boolean setTarget(String agno, String date);

	
}
