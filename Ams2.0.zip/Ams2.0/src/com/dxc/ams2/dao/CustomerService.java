package com.dxc.ams2.dao;

import java.util.List;


import com.dxc.ams2.entity.Customer;


public interface CustomerService {

	//public boolean login(String user,String pwd);
	public boolean changePwd(String id,String pwd);
	public List<Customer> viewCust(String id);
	
	
}
