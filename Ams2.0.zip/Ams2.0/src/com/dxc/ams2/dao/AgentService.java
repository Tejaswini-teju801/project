package com.dxc.ams2.dao;

import java.util.List;

import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Appointment;
import com.dxc.ams2.entity.Customer;
import com.dxc.ams2.entity.Policy;

public interface AgentService {


	//public boolean login(String user,String pwd);
	public List<Agent> viewAgent();
	public List<Policy> viewPolicy();
	public List<Customer> viewCustomer(String id);
	public boolean addCustomer(Customer cust);
	public boolean makeAppointment(Appointment appt);
	public List<Appointment> viewAppointment();
	public boolean deleteAppt(String id);
	
	
	
	
}
