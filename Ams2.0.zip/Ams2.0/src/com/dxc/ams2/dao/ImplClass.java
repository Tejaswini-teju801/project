package com.dxc.ams2.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Appointment;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.Customer;
import com.dxc.ams2.entity.Login;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.Policy;
import com.dxc.ams2.entity.ZonalManager;
import com.dxc.dbconnection.DbConnection;

public class ImplClass implements ZonalService, ManagerService, AgentService, CustomerService {

	Session s = DbConnection.connect();
//zonalservice method
	public List<ZonalManager> viewzonal() {
		Query q = s.createQuery("from ZonalManager e where e.zmid=:myid");
		q.setParameter("myid", "MG01");
		List<ZonalManager> l = q.list();
		return l;
	}
	//zonalservice method
	public boolean addManager(Manager mngr) {
		try {
			Transaction tx = s.beginTransaction();
			s.saveOrUpdate(mngr);
			Query q = s.createQuery("insert into Login(loginname,password) select c.loginname,c.password from Manager c where c.mgno = :id");
			q.setParameter("id",mngr.getMgno());
			q.executeUpdate();
			Query q1 = s.createQuery("update Login ln set ln.role = :newrole where ln.loginname = :myname and ln.password = :mypass");
			q1.setParameter("newrole","manager");
			q1.setParameter("myname",mngr.getLoginname());
			q1.setParameter("mypass",mngr.getPassword());
			q1.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	//zonalservice method
	public List<Manager> viewManager() {

		

		Query q = s.createQuery("from Manager mn");
		List<Manager> l = q.list();

		return l;
	}
	//zonalservice method
	public boolean addBranch(Branch br) {
		try {
			Transaction tx = s.beginTransaction();
			s.saveOrUpdate(br);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	//zonalservice method
	public List<Agent> viewAgent() {


		Query q = s.createQuery("from Agent ag");
		List<Agent> l = q.list();
	
		return l;
	}
	//zonalservice method
	public List<Policy> viewPolicy() {
	

		Query q = s.createQuery("from Policy pl");
		List<Policy> l = q.list();
		// System.out.println(l);
		return l;

	}
	//zonalservice method
	public boolean replaceManager(String id, String brno) {
		
	
		try {
			
			Transaction tx = s.beginTransaction();
			Query q = s.createQuery("update Manager mn set mn.brno = :mybrno where mn.mgno = :myid");
			q.setParameter("mybrno", brno);
			q.setParameter("myid", id);
			q.executeUpdate();
			tx.commit();
	
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	
		return true;

	}
	//managerservice method
	public boolean addAgent(Agent ag) {
		try {
			Transaction tx = s.beginTransaction();
			s.saveOrUpdate(ag);
			Query q = s.createQuery("insert into Login(loginname,password) select c.loginname,c.pwd from Agent c where c.agno = :id");
			q.setParameter("id",ag.getAgno());
			q.executeUpdate();
			Query q1 = s.createQuery("update Login ln set ln.role = :newrole where ln.loginname = :myname and ln.password = :mypass");
			q1.setParameter("newrole","agent");
			q1.setParameter("myname",ag.getLoginname());
			q1.setParameter("mypass",ag.getPwd());
			q1.executeUpdate();

			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	//managerservice method
	public List<Agent> viewPerformance() {

		

		Query q = s.createQuery("from Agent ag");
		List<Agent> l = q.list();


		return l;

	}
	//managerservice method
	public boolean setTarget(String agno, String date) {
		boolean flag = false;
		try {
			Transaction tx = s.beginTransaction();
			Query q = s.createQuery("update Agent mn set mn.targetsetdate = :mydate where mn.agno = :myid");
			q.setParameter("myid", agno);
			q.setParameter("mydate", date);
			q.executeUpdate();
			tx.commit();

			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return flag;
	}
	//agentservice method
	public List<Customer> viewCustomer(String id) {

		

		Query q = s.createQuery("from Customer c where c.agno = :ag");
		q.setParameter("ag", id);
		List<Customer> l = q.list();


		return l;

	}
	//agentservice method
	public boolean addCustomer(Customer cust) {
		try {
			Transaction tx = s.beginTransaction();
			s.saveOrUpdate(cust);
			Query q = s.createQuery("insert into Login(loginname,password) select c.cstloginname,c.cstpwd from Customer c where c.cstno = :id");
			q.setParameter("id",cust.getCstno());
			q.executeUpdate();
			Query q1 = s.createQuery("update Login ln set ln.role = :newrole where ln.loginname = :myname and ln.password = :mypass");
			q1.setParameter("newrole","customer");
			q1.setParameter("myname",cust.getCstloginname());
			q1.setParameter("mypass",cust.getCstpwd());
			q1.executeUpdate();

			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	//agentservice method
	public boolean makeAppointment(Appointment appt) {
		try {
			Transaction tx = s.beginTransaction();
			s.saveOrUpdate(appt);

			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	//agentservice method
	public List<Appointment> viewAppointment() {

		

		Query q = s.createQuery("from Appointment apt");
		List<Appointment> l = q.list();

		return l;

	}
	//agentservice method
	public boolean deleteAppt(String id) {
		try {
			Transaction tx = s.beginTransaction();
			Appointment appt=(Appointment)s.load(Appointment.class, id);
			s.delete(appt);
			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	//customerservice method
	public boolean changePwd(String id, String pwd) {

		try {
			Transaction tx = s.beginTransaction();
			Query q = s.createQuery("update Customer mn set mn.cstpwd = :newpwd where mn.cstno = :myid");
			q.setParameter("newpwd", pwd);
			q.setParameter("myid", id);
			q.executeUpdate();
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	//customerservice method
	public List<Customer> viewCust(String id) {
		
		Query q = s.createQuery("from Customer cust where cust.cstno =:mycstno ");
		q.setParameter("mycstno", id);
		List<Customer> l = q.list();
	
		return l;

	}

	/*
	  public boolean login(String user,String pwd) { boolean flag=true; try {
	  Transaction tx=s.beginTransaction();
	  
	  Query
	  q=s.createQuery("select ref.znloginname,ref.znpwd from ZonalManager ref");
	  List l=q.list(); Object[] ob=null; Iterator it=l.iterator();
	  while(it.hasNext()) { ob=(Object[])it.next();
	  System.out.println(ob[0]+" "+ob[1]);
	  
	  if(ob[0]=="teja"&&ob[1]=="teja") { flag= true;
	  System.out.println(ob[0]+" "+ob[1]); } else flag= false; }
	  
	  
	  
	  
	  Query qs=s. createQuery("from ZonalManager z where z.znloginname =:myln and z.znpwd=:myp " ); 
	  qs.setParameter("myln",user);
	  qs.setParameter("myp", pwd);
	  List<ZonalManager> ls=qs.list();
	  Iterator<ZonalManager> it=ls.iterator();
	  while(it.hasNext()) { 
		  ZonalManager obj=(ZonalManager)it.next(); 
		  String use=obj.getZnloginname(); 
		  String pw=obj.getZnpwd(); 
		  if((user==use)&&(pwd==pw)) { 
			  flag= true;
	  System.out.println(obj.getZnloginname()+" "+obj.getZnpwd());
	  } 
		  else flag=false; 
		  } 
	  tx.commit();
	  }catch(Exception e)
	  { e.printStackTrace(); }
	  return flag;
	  
	  }
	  
	 
*/
	public String loginz(Login login) {
		Query qs = s.createQuery("from Login z where z.loginname =:myln and z.password =:myp and z.role =:myrole");
		qs.setParameter("myln",login.getLoginname());
		qs.setParameter("myp", login.getPassword());
		qs.setParameter("myrole",login.getRole());
		List<Login> ls = qs.list();
		Iterator<Login> it = ls.iterator();
		String str = "";
		while (it.hasNext()) {
			Login obj = (Login) it.next();
			str = obj.getRole();
		}
		return str;

	}

	

}