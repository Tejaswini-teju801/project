package com.dxc.ams2.dao;

import java.util.List;

import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.Login;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.Policy;
import com.dxc.ams2.entity.ZonalManager;

public interface ZonalService {
	public String loginz(Login login);
	//public boolean login(String user,String pwd);
	public List<ZonalManager> viewzonal();
	public boolean addManager(Manager mngr);
	public List<Manager> viewManager();
	public boolean addBranch(Branch br);
	public List<Agent> viewAgent();
	public List<Policy> viewPolicy();
	public boolean replaceManager(String id,String brno);

}
