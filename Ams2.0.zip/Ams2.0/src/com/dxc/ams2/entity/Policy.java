package com.dxc.ams2.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="policy")
public class Policy {
	@Id
	@Column(name="pid")
	String pid;
	@Column(name="cstno")
	String cstno;
	@Column(name="pdate")
	String pdate;
	@Column(name="years")
	int years;
	@Column(name="pamt")
	int pamt;
	@Column(name="premium")
	int premium;
	@Column(name="mode")
	String mode;
	
	public Policy(String pid, String cstno, String pdate, int years, int pamt, int premium, String mode) {
		super();
		this.pid = pid;
		this.cstno = cstno;
		this.pdate = pdate;
		this.years = years;
		this.pamt = pamt;
		this.premium = premium;
		this.mode = mode;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getCstno() {
		return cstno;
	}
	public void setCstno(String cstno) {
		this.cstno = cstno;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	
	public int getYears() {
		return years;
	}
	public void setYears(int years) {
		this.years = years;
	}
	public int getPamt() {
		return pamt;
	}
	public void setPamt(int pamt) {
		this.pamt = pamt;
	}
	public int getPremium() {
		return premium;
	}
	public void setPremium(int premium) {
		this.premium = premium;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	@Override
	public String toString() {
		return "Policy [pid=" + pid + ", cstno=" + cstno + ", pdate=" + pdate + ", years=" + years + ", pamt=" + pamt
				+ ", premium=" + premium + ", mode=" + mode + "]";
	}
	
	
	public Policy()
	{
		
	}
	
	
}
