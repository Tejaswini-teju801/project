package com.dxc.ams2.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="appt")
public class Appointment {
	@Id
	@Column(name="apptno")
String apptno;
	@Column(name="agno")
String agno;
	@Column(name="apptdate")
String apptdate;
	@Column(name="time")
String time;
	@Column(name="cstname")
String cstname;
	@Column(name="cstno")
	String cstno;

public Appointment(String apptno, String agno, String apptdate, String time, String cstname, String cstno) {
		super();
		this.apptno = apptno;
		this.agno = agno;
		this.apptdate = apptdate;
		this.time = time;
		this.cstname = cstname;
		this.cstno = cstno;
	}

public String getCstno() {
	return cstno;
}

public void setCstno(String cstno) {
	this.cstno = cstno;
}

@Override
public String toString() {
	return "Appointment [apptno=" + apptno + ", agno=" + agno + ", apptdate=" + apptdate + ", time=" + time
			+ ", cstname=" + cstname + "]";
}
public String getApptno() {
	return apptno;
}
public void setApptno(String apptno) {
	this.apptno = apptno;
}
public String getAgno() {
	return agno;
}
public void setAgno(String agno) {
	this.agno = agno;
}
public String getApptdate() {
	return apptdate;
}
public void setApptdate(String apptdate) {
	this.apptdate = apptdate;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getCstname() {
	return cstname;
}
public void setCstname(String cstname) {
	this.cstname = cstname;
}

	
	
	
	public Appointment()
	{
		
	}
	
	
	
	
}
