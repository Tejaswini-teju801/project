package com.dxc.ams2.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="zonalmanager")
public class ZonalManager {
@Id
@Column(name="zmid")
String zmid;

@Column(name="firstname")
	String znfirstname;
@Column(name="lastname")
	String znlastname;
@Column(name="loginname")
	String znloginname;
@Column(name="loginpwd")
	String znpwd;
@Column(name="email")
	String znemail;
@Column(name="phoneno")
	String znphno;
	
	public ZonalManager(String zmid, String znfirstname, String znlastname, String znloginname, String znpwd,
			String znemail, String znphno) {
		super();
		this.zmid = zmid;
		this.znfirstname = znfirstname;
		this.znlastname = znlastname;
		this.znloginname = znloginname;
		this.znpwd = znpwd;
		this.znemail = znemail;
		this.znphno = znphno;
	}
	
	
	public String getZnemail() {
		return znemail;
	}


	public void setZnemail(String znemail) {
		this.znemail = znemail;
	}


	public String getZmid() {
		return zmid;
	}
	public void setZmno(String zmid) {
		this.zmid = zmid;
	}
	public String getZnfirstname() {
		return znfirstname;
	}
	public void setZnfirstname(String znfirstname) {
		this.znfirstname = znfirstname;
	}
	public String getZnlastname() {
		return znlastname;
	}
	public void setZnlastname(String znlastname) {
		this.znlastname = znlastname;
	}
	public String getZnloginname() {
		return znloginname;
	}
	public void setZnloginname(String znloginname) {
		this.znloginname = znloginname;
	}
	public String getZnpwd() {
		return znpwd;
	}
	public void setZnpwd(String znpwd) {
		this.znpwd = znpwd;
	}
	public String getZnphno() {
		return znphno;
	}
	public void setZnphno(String znphno) {
		this.znphno = znphno;
	}


	@Override
	public String toString() {
		return "ZonalManager [zmid=" + zmid + ", znfirstname=" + znfirstname + ", znlastname=" + znlastname
				+ ", znloginname=" + znloginname + ", znpwd=" + znpwd + ", znemail=" + znemail + ", znphno=" + znphno
				+ "]";
	}
	
	
	public ZonalManager()
	{
		
	}
	
	
	
}
